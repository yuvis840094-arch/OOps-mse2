import java.sql.*;
import java.util.Scanner;

public class Main {

    static final String URL = "jdbc:mysql://localhost:3306/ecommerce_db";
    static final String USER = "root";
    static final String PASSWORD = "Yuvi@010203";

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {

            System.out.println("Connected to MySQL successfully!");

            int choice;

            do {

                System.out.println("\n===== ORDER MANAGEMENT SYSTEM =====");
                System.out.println("1. Insert 3 Orders");
                System.out.println("2. Search Orders by Status");
                System.out.println("3. Increase Order Quantity");
                System.out.println("4. Update Order Status");
                System.out.println("5. Display Total Order Value");
                System.out.println("6. Delete Cancelled Order");
                System.out.println("7. Exit");

                System.out.print("Enter your choice: ");
                choice = sc.nextInt();

                switch (choice) {

                    case 1:
                        insertOrders(con);
                        break;

                    case 2:
                        searchOrders(con);
                        break;

                    case 3:
                        increaseQuantity(con);
                        break;

                    case 4:
                        updateStatus(con);
                        break;

                    case 5:
                        displayTotalValue(con);
                        break;

                    case 6:
                        deleteCancelledOrder(con);
                        break;

                    case 7:
                        System.out.println("Exiting application...");
                        break;

                    default:
                        System.out.println("Invalid choice!");
                }

            } while (choice != 7);

        } catch (SQLException e) {

            System.out.println("Database error: " + e.getMessage());

        }
    }

    // 1. INSERT THREE ORDERS

    static void insertOrders(Connection con) {

        String sql = "INSERT INTO Orders VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            for (int i = 1; i <= 3; i++) {

                System.out.println("\nEnter details for Order " + i);

                System.out.print("Order ID: ");
                int id = sc.nextInt();
                sc.nextLine();

                System.out.print("Customer Name: ");
                String customer = sc.nextLine();

                System.out.print("Product Name: ");
                String product = sc.nextLine();

                System.out.print("Quantity: ");
                int quantity = sc.nextInt();

                System.out.print("Unit Price: ");
                double price = sc.nextDouble();
                sc.nextLine();

                System.out.print("Status: ");
                String status = sc.nextLine();

                ps.setInt(1, id);
                ps.setString(2, customer);
                ps.setString(3, product);
                ps.setInt(4, quantity);
                ps.setDouble(5, price);
                ps.setString(6, status);

                try {

                    ps.executeUpdate();
                    System.out.println("Order inserted successfully!");

                } catch (SQLIntegrityConstraintViolationException e) {

                    System.out.println("Duplicate Order ID! Record not inserted.");

                }
            }

        } catch (SQLException e) {

            System.out.println("Error: " + e.getMessage());

        }
    }

    // 2. SEARCH ORDERS BY STATUS AND QUANTITY > 2

    static void searchOrders(Connection con) {

        String sql = "SELECT * FROM Orders WHERE status = ? AND quantity > 2 ORDER BY unit_price DESC";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            System.out.print("Enter order status: ");
            String status = sc.nextLine();

            ps.setString(1, status);

            ResultSet rs = ps.executeQuery();

            System.out.println("\n===== ORDER DETAILS =====");

            boolean found = false;

            while (rs.next()) {

                found = true;

                System.out.println(
                        "ID: " + rs.getInt("order_id") +
                        ", Customer: " + rs.getString("customer_name") +
                        ", Product: " + rs.getString("product_name") +
                        ", Quantity: " + rs.getInt("quantity") +
                        ", Price: " + rs.getDouble("unit_price") +
                        ", Status: " + rs.getString("status")
                );
            }

            if (!found) {
                System.out.println("No matching orders found.");
            }

        } catch (SQLException e) {

            System.out.println("Error: " + e.getMessage());

        }
    }

    // 3. INCREASE QUANTITY

    static void increaseQuantity(Connection con) {

        String sql = "UPDATE Orders SET quantity = quantity + ? WHERE order_id = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            System.out.print("Enter Order ID: ");
            int id = sc.nextInt();

            System.out.print("Enter additional quantity: ");
            int additional = sc.nextInt();
            sc.nextLine();

            ps.setInt(1, additional);
            ps.setInt(2, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {

                System.out.println("Quantity updated successfully!");

            } else {

                System.out.println("Order does not exist.");
            }

        } catch (SQLException e) {

            System.out.println("Error: " + e.getMessage());

        }
    }

    // 4. UPDATE STATUS

    static void updateStatus(Connection con) {

        System.out.print("Enter Order ID: ");
        int id = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter new status: ");
        String newStatus = sc.nextLine();

        if (!(newStatus.equalsIgnoreCase("Pending") ||
              newStatus.equalsIgnoreCase("Shipped") ||
              newStatus.equalsIgnoreCase("Delivered"))) {

            System.out.println("Invalid status!");
            return;
        }

        String sql = "UPDATE Orders SET status = ? WHERE order_id = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, newStatus);
            ps.setInt(2, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {

                System.out.println("Status updated successfully!");

                displayOrderById(con, id);

            } else {

                System.out.println("Order does not exist.");
            }

        } catch (SQLException e) {

            System.out.println("Error: " + e.getMessage());

        }
    }

    // DISPLAY UPDATED ORDER

    static void displayOrderById(Connection con, int id) {

        String sql = "SELECT * FROM Orders WHERE order_id = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                System.out.println("\n===== UPDATED ORDER =====");

                System.out.println("Order ID: " + rs.getInt("order_id"));
                System.out.println("Customer: " + rs.getString("customer_name"));
                System.out.println("Product: " + rs.getString("product_name"));
                System.out.println("Quantity: " + rs.getInt("quantity"));
                System.out.println("Unit Price: " + rs.getDouble("unit_price"));
                System.out.println("Status: " + rs.getString("status"));
            }

        } catch (SQLException e) {

            System.out.println("Error: " + e.getMessage());

        }
    }

    // 5. DISPLAY TOTAL ORDER VALUE

    static void displayTotalValue(Connection con) {

        String sql = "SELECT SUM(quantity * unit_price) AS total FROM Orders";

        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            if (rs.next()) {

                System.out.println("Total Order Value: " + rs.getDouble("total"));
            }

        } catch (SQLException e) {

            System.out.println("Error: " + e.getMessage());

        }
    }

    // 6. DELETE CANCELLED ORDER

    static void deleteCancelledOrder(Connection con) {

        String sql = "DELETE FROM Orders WHERE order_id = ? AND status = 'Cancelled'";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            System.out.print("Enter Order ID to delete: ");
            int id = sc.nextInt();
            sc.nextLine();

            ps.setInt(1, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {

                System.out.println("Cancelled order deleted successfully!");

            } else {

                System.out.println("Order cannot be deleted. It either does not exist or is not Cancelled.");
            }

        } catch (SQLException e) {

            System.out.println("Error: " + e.getMessage());

        }
    }
}