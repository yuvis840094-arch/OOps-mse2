package com.kiet.library.controller;

import java.util.List;
import java.util.ArrayList;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import com.kiet.library.model.Book;

@RestController
@RequestMapping("/books")

public class BookController {

    // Empty list to store books
    List<Book> books = new ArrayList<>();


    // B. ADD NEW BOOK
    // POST /books

    @PostMapping
    public ResponseEntity<Book> addBook(@RequestBody Book b) {

        books.add(b);

        return new ResponseEntity<>(b, HttpStatus.CREATED);
    }


    // C1. GET ALL BOOKS
    // GET /books

    @GetMapping
    public List<Book> getAllBooks() {

        return books;
    }


    // C2. GET BOOK BY ID
    // GET /books/{id}

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Integer id) {

        for (Book b : books) {

            if (b.getId().equals(id)) {

                return ResponseEntity.ok(b);
            }
        }

        return ResponseEntity.notFound().build();
    }


    // D. UPDATE BOOK
    // PUT /books/{id}

    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(
            @PathVariable Integer id,
            @RequestBody Book newBook) {

        for (Book b : books) {

            if (b.getId().equals(id)) {

                b.setTitle(newBook.getTitle());
                b.setAuthor(newBook.getAuthor());
                b.setCategory(newBook.getCategory());
                b.setAvailableCopies(newBook.getAvailableCopies());

                return ResponseEntity.ok(b);
            }
        }

        return ResponseEntity.notFound().build();
    }


    // E. DELETE BOOK
    // DELETE /books/{id}

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBook(@PathVariable Integer id) {

        for (Book b : books) {

            if (b.getId().equals(id)) {

                books.remove(b);

                return ResponseEntity.ok("Book deleted successfully");
            }
        }

        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("Book not found");
    }

}